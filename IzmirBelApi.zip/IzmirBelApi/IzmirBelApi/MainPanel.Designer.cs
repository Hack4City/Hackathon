﻿using MetroFramework.Controls;

namespace IzmirBelApi
{
    partial class MainPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.ListViewItem listViewItem6 = new System.Windows.Forms.ListViewItem("F.ALTAY BEKLEYEN: 5");
            System.Windows.Forms.ListViewItem listViewItem7 = new System.Windows.Forms.ListViewItem("GÖZTEPE BEKLEYEN: 8");
            System.Windows.Forms.ListViewItem listViewItem8 = new System.Windows.Forms.ListViewItem("ORIGINN BEKLEYEN: 6");
            System.Windows.Forms.ListViewItem listViewItem9 = new System.Windows.Forms.ListViewItem("169 F.ALTAY - KONAK");
            System.Windows.Forms.ListViewItem listViewItem10 = new System.Windows.Forms.ListViewItem("169 KONAK - F.ALTAY");
            this.borderPanel = new System.Windows.Forms.Panel();
            this.headerText = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.minimizeButton = new System.Windows.Forms.PictureBox();
            this.closeButton = new System.Windows.Forms.PictureBox();
            this.arduinoPort = new System.IO.Ports.SerialPort(this.components);
            this.tabControlEX1 = new Dotnetrix.Controls.TabControlEX();
            this.tabPageEX3 = new Dotnetrix.Controls.TabPageEX();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.listView2 = new System.Windows.Forms.ListView();
            this.listView1 = new System.Windows.Forms.ListView();
            this.tabPageEX2 = new Dotnetrix.Controls.TabPageEX();
            this.log = new System.Windows.Forms.RichTextBox();
            this.HATLAR = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.DURAKLAR = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.borderPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.minimizeButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.closeButton)).BeginInit();
            this.tabControlEX1.SuspendLayout();
            this.tabPageEX3.SuspendLayout();
            this.tabPageEX2.SuspendLayout();
            this.SuspendLayout();
            // 
            // borderPanel
            // 
            this.borderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(18)))), ((int)(((byte)(18)))));
            this.borderPanel.Controls.Add(this.headerText);
            this.borderPanel.Controls.Add(this.pictureBox1);
            this.borderPanel.Controls.Add(this.minimizeButton);
            this.borderPanel.Controls.Add(this.closeButton);
            this.borderPanel.Location = new System.Drawing.Point(0, 0);
            this.borderPanel.Name = "borderPanel";
            this.borderPanel.Size = new System.Drawing.Size(727, 31);
            this.borderPanel.TabIndex = 0;
            this.borderPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.borderPanel_Paint);
            this.borderPanel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.borderPanel_MouseDown);
            // 
            // headerText
            // 
            this.headerText.AutoSize = true;
            this.headerText.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.headerText.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.headerText.Location = new System.Drawing.Point(34, 6);
            this.headerText.Name = "headerText";
            this.headerText.Size = new System.Drawing.Size(153, 18);
            this.headerText.TabIndex = 1;
            this.headerText.Text = "Bus-Gelsin Server";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::IzmirBelApi.Properties.Resources.busLogo;
            this.pictureBox1.Location = new System.Drawing.Point(12, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(25, 25);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // minimizeButton
            // 
            this.minimizeButton.BackColor = System.Drawing.Color.Orange;
            this.minimizeButton.Location = new System.Drawing.Point(662, 3);
            this.minimizeButton.Name = "minimizeButton";
            this.minimizeButton.Size = new System.Drawing.Size(26, 10);
            this.minimizeButton.TabIndex = 1;
            this.minimizeButton.TabStop = false;
            this.minimizeButton.Click += new System.EventHandler(this.minimizeButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.BackColor = System.Drawing.Color.Red;
            this.closeButton.Location = new System.Drawing.Point(694, 3);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(26, 10);
            this.closeButton.TabIndex = 1;
            this.closeButton.TabStop = false;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // tabControlEX1
            // 
            this.tabControlEX1.Appearance = Dotnetrix.Controls.TabAppearanceEX.FlatTab;
            this.tabControlEX1.BackColor = System.Drawing.Color.Transparent;
            this.tabControlEX1.Controls.Add(this.tabPageEX3);
            this.tabControlEX1.Controls.Add(this.tabPageEX2);
            this.tabControlEX1.FlatBorderColor = System.Drawing.Color.Transparent;
            this.tabControlEX1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tabControlEX1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tabControlEX1.HotColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.tabControlEX1.HotTrack = true;
            this.tabControlEX1.Location = new System.Drawing.Point(11, 37);
            this.tabControlEX1.Name = "tabControlEX1";
            this.tabControlEX1.SelectedIndex = 0;
            this.tabControlEX1.SelectedTabColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.tabControlEX1.SelectedTabFontStyle = System.Drawing.FontStyle.Regular;
            this.tabControlEX1.Size = new System.Drawing.Size(704, 383);
            this.tabControlEX1.TabColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.tabControlEX1.TabIndex = 1;
            this.tabControlEX1.UseVisualStyles = false;
            // 
            // tabPageEX3
            // 
            this.tabPageEX3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPageEX3.Controls.Add(this.label2);
            this.tabPageEX3.Controls.Add(this.label1);
            this.tabPageEX3.Controls.Add(this.listView2);
            this.tabPageEX3.Controls.Add(this.listView1);
            this.tabPageEX3.Location = new System.Drawing.Point(4, 25);
            this.tabPageEX3.Name = "tabPageEX3";
            this.tabPageEX3.Size = new System.Drawing.Size(696, 354);
            this.tabPageEX3.TabIndex = 2;
            this.tabPageEX3.Text = "Yolcular";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(352, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Duraklar";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Hatlar";
            // 
            // listView2
            // 
            this.listView2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.DURAKLAR});
            this.listView2.ForeColor = System.Drawing.SystemColors.Info;
            this.listView2.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem6,
            listViewItem7,
            listViewItem8});
            this.listView2.Location = new System.Drawing.Point(355, 26);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(317, 305);
            this.listView2.TabIndex = 0;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = System.Windows.Forms.View.Details;
            // 
            // listView1
            // 
            this.listView1.AutoArrange = false;
            this.listView1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.HATLAR});
            this.listView1.ForeColor = System.Drawing.SystemColors.Info;
            this.listView1.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem9,
            listViewItem10});
            this.listView1.Location = new System.Drawing.Point(21, 26);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(317, 305);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // tabPageEX2
            // 
            this.tabPageEX2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPageEX2.Controls.Add(this.log);
            this.tabPageEX2.Location = new System.Drawing.Point(4, 25);
            this.tabPageEX2.Name = "tabPageEX2";
            this.tabPageEX2.Size = new System.Drawing.Size(696, 354);
            this.tabPageEX2.TabIndex = 1;
            this.tabPageEX2.Text = "Log";
            // 
            // log
            // 
            this.log.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.log.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.log.Location = new System.Drawing.Point(21, 15);
            this.log.Name = "log";
            this.log.Size = new System.Drawing.Size(651, 323);
            this.log.TabIndex = 1;
            this.log.Text = "";
            // 
            // HATLAR
            // 
            this.HATLAR.Text = "HATLAR";
            this.HATLAR.Width = 178;
            // 
            // DURAKLAR
            // 
            this.DURAKLAR.Width = 192;
            // 
            // MainPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.ClientSize = new System.Drawing.Size(727, 432);
            this.Controls.Add(this.tabControlEX1);
            this.Controls.Add(this.borderPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MainPanel";
            this.Text = "MainPanel";
            this.Load += new System.EventHandler(this.MainPanel_Load);
            this.borderPanel.ResumeLayout(false);
            this.borderPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.minimizeButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.closeButton)).EndInit();
            this.tabControlEX1.ResumeLayout(false);
            this.tabPageEX3.ResumeLayout(false);
            this.tabPageEX3.PerformLayout();
            this.tabPageEX2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel borderPanel;
        private System.Windows.Forms.PictureBox minimizeButton;
        private System.Windows.Forms.PictureBox closeButton;
        private System.IO.Ports.SerialPort arduinoPort;
        private System.Windows.Forms.Label headerText;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Dotnetrix.Controls.TabControlEX tabControlEX1;
        private Dotnetrix.Controls.TabPageEX tabPageEX2;
        private Dotnetrix.Controls.TabPageEX tabPageEX3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.RichTextBox log;
        private System.Windows.Forms.ColumnHeader DURAKLAR;
        private System.Windows.Forms.ColumnHeader HATLAR;
    }
}