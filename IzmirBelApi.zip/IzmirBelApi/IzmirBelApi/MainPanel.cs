﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.ServiceModel.Security;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using IzmirBelApi.Hackathon;
using IzmirBelApi.Helpers;
using IzmirBelApi.Net;
using IzmirBelApi.SmartCity;
using IzmirBelApi.SmartCity.Commands;
using IzmirBelApi.SmartCity.Commands.Incoming;
using IzmirBelApi.SmartCity.Commands.Outgoing;
using log4net;
using log4net.Core;

namespace IzmirBelApi
{
    public partial class MainPanel : Form
    {
        private bool _abort;
        private static readonly ILog Log = LogManager.GetLogger(typeof(MainPanel));
        private static AsynchronousSocketListener _asynchronousSocketListener;
        public MainPanel()
        {
            InitializeComponent();
            InitializeLogger();
            InitializeServer();
            CommandHandler.AddHandlers();
            Api.Initialize();
            InitializeSerialPort();
        }
        private async void InitializeSerialPort()
        {
            arduinoPort.PortName = "COM4";
            arduinoPort.BaudRate = 9600;
            arduinoPort.Open();
            Log.Debug("Arduino connection established.");

           await Task.Run(()=>ListenSerialPort());
        }
        private async void ListenSerialPort()
        {
            await Task.Delay(500);
            while (!_abort)
            {
                if (InvokeRequired)
                {
                    Invoke(new Action(HandleSerialPort));
                }
                else
                {
                    HandleSerialPort();
                }
                await Task.Delay(100);
            }
        }
        private void HandleSerialPort()
        {
            if (arduinoPort.BytesToRead <= 0) return;
            var data = arduinoPort.ReadLine().Split('|');
            switch (data[0])
            {
                case "PAYMENT":
                    //var client = SessionManager.Sessions.FirstOrDefault(x => x.Token == data[1]);
                    //if(client != null)
                    //SendSerialPort($"PAYMENT_SUCCESS {client.Balance - 2.6}");
                    SendSerialPort($"PAYMENT_SUCCESS 4");
                    break;
                case "STATIONNAME":
                    SendSerialPort("STATIONNAME|ORIGIN");
                    break;
                case "STATION":
                    //var client = SessionManager.Sessions.FirstOrDefault(x => x.Token == data[1]);
                    //if(client != null)
                    //SendSerialPort($"PAYMENT_SUCCESS {client.Balance - 2.6}");
                    SendSerialPort($"STATION|20|5|10|3");
                    break;
                default:
                    Log.Error($"Unknown serial port message: {string.Join("|", data)}");
                    break;
            }
        }

        public void SendSerialPort(string data)
        {
            arduinoPort.WriteLine(data);
        }
        private static void InitializeServer()
        {
            _asynchronousSocketListener = new AsynchronousSocketListener(new IPEndPoint(IPAddress.Any, 8080),
                5, SessionManager.HandleIncomingConnection);
            Log.Debug("Server initialized.");
        }
        private void InitializeLogger()
        {
            RichTextBoxAppender.SetRichTextBox(log);
            var ilts = new LevelTextStyle
            {
                Level = Level.Info,
                PointSize = 10.0f
            };
            RichTextBoxAppender.AddMapping(ilts);
            var dlts = new LevelTextStyle
            {
                Level = Level.Debug,
                PointSize = 10.0f
            };
            RichTextBoxAppender.AddMapping(dlts);
            var wlts = new LevelTextStyle
            {
                Level = Level.Warn,
                PointSize = 10.0f
            };
            RichTextBoxAppender.AddMapping(wlts);
            var elts = new LevelTextStyle
            {
                Level = Level.Error,
                PointSize = 10.0f
            };
            RichTextBoxAppender.AddMapping(elts);
        }
        #region Drag Move
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool ReleaseCapture();
        #endregion
        private void borderPanel_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;
            ReleaseCapture();
            SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(@"Do you really want to stop Bus-Gelsin server?", @"Bus-Gelsin", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                _abort = true;
                Close();
            }
        }

        private void minimizeButton_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void MainPanel_Load(object sender, EventArgs e)
        {

        }

        private void borderPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
