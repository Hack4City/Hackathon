﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel.Security;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using IzmirBelApi.Hackathon;
using log4net;
using Microsoft.VisualBasic.Logging;

namespace IzmirBelApi.Helpers
{
    static class Api
    {
        private const string Username = "UBSWS_HACKATHON";
        private const string Password = "re7Phy";
        private static readonly ILog Log = LogManager.GetLogger(typeof(MainPanel));
        private static UbsWSSoapClient _client;
        public static void Initialize()
        {
            try
            {
                _client = new UbsWSSoapClient();
                //MessageBox.Show(_client.GetClosestBus(stationId, Username, Password).Result.BakiyeSonuc);
                Log.Debug("Connected to Izmir Service Api.");
            }
            catch (Exception e)
            {
                Log.Fatal($"Cannot connect to Api. {e.Message}");
            }
        }

        public static Dictionary<string, int> GetClosestBus(int tripId, int stationId)
        {
            //var durak = _client.HatDuraklariniGetir(169, Username, Password); //Exception :Sunucu protokol ihlalinde bulundu. Section=ResponseStatusLine
            return new Dictionary<string, int>
            {
                {"minutes", 9 },
                {"stationId", 0 }
            };
        }
    }
}
