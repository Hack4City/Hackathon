﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IzmirBelApi.Helpers
{
    static class Randomizer
    {
        private static readonly Random Random = new Random();
        private const string Characters = "qwertyuopasdfghjklzxcvbnm013456789";
        private static readonly object SyncLock = new object();
        public static int Get(int min, int max)
        {
            lock (SyncLock)
            {
                var result = Random.Next(min, max);
                return result;
            }
        }
        public static string Hash()
        {
            var randomString = "";
            lock (SyncLock)
            {
                var lenght = Get(5, 7);
                for (var i = 0; i < lenght; i++)
                {
                    randomString += Characters[Get(0, Characters.Length)];
                }
                return randomString;
            }
        }

    }
}
