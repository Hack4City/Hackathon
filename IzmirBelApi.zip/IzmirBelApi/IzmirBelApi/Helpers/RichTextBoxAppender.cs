﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using log4net;
using log4net.Appender;
using log4net.Core;
using log4net.Repository.Hierarchy;
using log4net.Util;

namespace IzmirBelApi.Helpers
{
    /// <summary> 
    /// Description of RichTextBoxAppender. 
    /// </summary> 
    public class RichTextBoxAppender : AppenderSkeleton
    {
        private delegate void UpdateControlDelegate(LoggingEvent loggingEvent);
        public RichTextBox RichTextBox { set; get; }
        public LevelMapping LevelMapping { set; get; } = new LevelMapping();
        private void UpdateControl(LoggingEvent loggingEvent)
        {
            if (RichTextBox.TextLength > 100000)
            {
                RichTextBox.Clear();
                RichTextBox.SelectionColor = Color.Gray;
            }

            var selectedStyle = LevelMapping.Lookup(loggingEvent.Level) as LevelTextStyle;
            if (selectedStyle != null)
            {
                if (selectedStyle.Font != null)
                {
                    RichTextBox.SelectionFont = selectedStyle.Font;
                }
                else if (selectedStyle.PointSize > 0 && RichTextBox.Font.SizeInPoints != selectedStyle.PointSize)
                {
                    var size = selectedStyle.PointSize > 0.0f
                        ? selectedStyle.PointSize
                        : RichTextBox.Font.SizeInPoints;
                    RichTextBox.SelectionFont = new Font(RichTextBox.Font.FontFamily.Name, size, selectedStyle.FontStyle);
                }
                else if (RichTextBox.Font.Style != selectedStyle.FontStyle)
                {
                    RichTextBox.SelectionFont = new Font(RichTextBox.Font, selectedStyle.FontStyle);
                }
            }
            switch (loggingEvent.Level.ToString())
            {
                case "INFO":
                    RichTextBox.SelectionColor = Color.BlueViolet;
                    break;
                case "WARN":
                    RichTextBox.SelectionColor = Color.Gold;
                    break;
                case "ERROR":
                    RichTextBox.SelectionColor = Color.Red;
                    break;
                case "FATAL":
                    RichTextBox.SelectionColor = Color.DarkOrange;
                    break;
                case "DEBUG":
                    RichTextBox.SelectionColor = Color.DarkGreen;
                    break;
                default:
                    RichTextBox.SelectionColor = Color.Black;
                    break;
            }
            var stringWriter = new StringWriter(CultureInfo.InvariantCulture);
            Layout.Format(stringWriter, loggingEvent);
            RichTextBox.AppendText(stringWriter.ToString());
        }
        public static void AddMapping(LevelTextStyle mapping)
        {
            foreach (var appender in GetAppenders().OfType<RichTextBoxAppender>())
            {
                (appender).LevelMapping.Add(mapping);
            }
        }


        protected override void Append(LoggingEvent loggingEvent)
        {
            if (RichTextBox == null) return;
            if (RichTextBox.InvokeRequired)
            {
                RichTextBox.Invoke(new UpdateControlDelegate(UpdateControl), loggingEvent);
            }
            else
            {
                UpdateControl(loggingEvent);
            }
        }


        public static void SetRichTextBox(RichTextBox rtb)
        {
            rtb.ReadOnly = true;
            rtb.HideSelection = false; 
            foreach (var appender in GetAppenders().OfType<RichTextBoxAppender>())
            {
                (appender).RichTextBox = rtb;
            }
        }
        private static IEnumerable<IAppender> GetAppenders()
        {
            var appenders = new ArrayList();
            appenders.AddRange(((Hierarchy)LogManager.GetRepository()).Root.Appenders);
            foreach (var log in LogManager.GetCurrentLoggers())
            {
                appenders.AddRange(((Logger)log.Logger).Appenders);
            }
            return (IAppender[])appenders.ToArray(typeof(IAppender));
        }

    }

    public class LevelTextStyle : LevelMappingEntry
    {
        private Color _textColor;
        private Color _backColor;
        private FontStyle _fontStyle = FontStyle.Regular;
        private float _pointSize = 0.0f;
        private bool _bold = false;
        private bool _italic = false;
        private string _fontFamilyName = null;
        private Font _font = null;

        public bool Bold { get { return _bold; } set { _bold = value; } }
        public bool Italic { get { return _italic; } set { _italic = value; } }
        public float PointSize { get { return _pointSize; } set { _pointSize = value; } }

        public override void ActivateOptions()
        {
            base.ActivateOptions();
            if (_bold) _fontStyle |= FontStyle.Bold;
            if (_italic) _fontStyle |= FontStyle.Italic;

            if (_fontFamilyName != null)
            {
                float size = _pointSize > 0.0f ? _pointSize : 8.25f;
                try
                {
                    _font = new Font(_fontFamilyName, size, _fontStyle);
                }
                catch (Exception)
                {
                    _font = new Font("Arial", 8.25f, FontStyle.Regular);
                }
            }
        }

        public Color TextColor { get { return _textColor; } set { _textColor = value; } }
        public Color BackColor { get { return _backColor; } set { _backColor = value; } }
        public FontStyle FontStyle { get { return _fontStyle; } set { _fontStyle = value; } }
        public Font Font { get { return _font; } set { _font = value; } }
    }
}


