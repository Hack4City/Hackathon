﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IzmirBelApi.SmartCity.Commands.Incoming
{
    internal interface IHandler
    {
        void Run(PacketParser packet, Client client);
    }
}
