﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IzmirBelApi.Helpers;
using IzmirBelApi.SmartCity.Commands.Outgoing;

namespace IzmirBelApi.SmartCity.Commands.Incoming
{
    internal class AuthRequest : IHandler
    {
        public void Run(PacketParser packet, Client client)
        {
            var izmirCardId = packet.ReadString();
            var telNumber = packet.ReadString();
            var token = Randomizer.Hash();
            client.Token = token;
            client.Send(new AuthCommand(true, token));
        }
    }
}
