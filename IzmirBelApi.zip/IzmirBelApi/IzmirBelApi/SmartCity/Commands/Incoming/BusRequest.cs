﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IzmirBelApi.Helpers;
using IzmirBelApi.SmartCity.Commands.Outgoing;

namespace IzmirBelApi.SmartCity.Commands.Incoming
{
    internal class BusRequest : IHandler
    {
        public void Run(PacketParser packet, Client client)
        {
            var tripId = packet.ReadInt();
            client.Send(new BusInfoCommand(Api.GetClosestBus(tripId, -1)));
        }
    }
}
