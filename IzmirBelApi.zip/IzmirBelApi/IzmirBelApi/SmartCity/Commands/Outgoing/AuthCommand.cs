﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IzmirBelApi.SmartCity.Commands.Outgoing
{
    class AuthCommand : Command
    {
        public AuthCommand(bool success, string token)
        {
            Write("AUTH_RESPONSE");
            Write(success ? "SUCCESS" : "FAIL");
            Write(token);
        }
    }
}
