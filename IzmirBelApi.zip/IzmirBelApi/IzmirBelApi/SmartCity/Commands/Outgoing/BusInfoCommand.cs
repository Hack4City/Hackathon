﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace IzmirBelApi.SmartCity.Commands.Outgoing
{
    internal class BusInfoCommand : Command
    {
        public BusInfoCommand(IReadOnlyDictionary<string, int> busData)
        {
            Write("STATION");//BUS_INFO
            Write(20);//requested person count
            Write(5);//early bus take off
            Write(10);//time left to arrive to stationId
            Write(3);//station count between bus
        }
    }
}
