﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IzmirBelApi.SmartCity.Commands.Outgoing
{
    internal abstract class Command
    {
        public string Data => string.Join("|", _data);

        private List<string> _data;

        protected Command()
        {
            _data = new List<string>();
        }
        public void Write(object obj)
        {
            _data.Add(obj.ToString());
        }
    }
}
