﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IzmirBelApi.SmartCity.Commands.Outgoing
{
    class PaymentCommand : Command
    {
        public PaymentCommand(bool success, double balance)
        {
            Write("PAYMENT_RESPONSE");
            Write(success ? "SUCCESS" : "FAIL");
            Write(balance);
        }

    }
}
