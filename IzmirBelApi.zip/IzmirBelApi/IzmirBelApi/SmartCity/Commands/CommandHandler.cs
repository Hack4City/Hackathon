﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IzmirBelApi.SmartCity.Commands.Incoming;

namespace IzmirBelApi.SmartCity.Commands
{
    internal static class CommandHandler
    {
        public static Dictionary<string, IHandler> Handlers { get; set; }
        public static void AddHandler(string name, IHandler handler)
        {
            if (Handlers.ContainsKey(name)) return;
                Handlers.Add(name, handler);
        }
        public static void AddHandlers()
        {
            Handlers = new Dictionary<string, IHandler>();
            AddHandler("AUTH_REQUEST", new AuthRequest());
            AddHandler("BUS_REQUEST", new BusRequest());
        }

    }
}
