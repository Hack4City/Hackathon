﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using log4net;

namespace IzmirBelApi.SmartCity.Commands.Incoming
{
    internal class PacketParser : IDisposable
    {
        public string Id { get; set; }
        public int Length { get; set; }
        private string[] _data;
        private int _pointer;
        public bool MoreToRead => Length > _pointer;
        private static readonly ILog Log = LogManager.GetLogger(typeof(PacketParser));
        public PacketParser(string data)
        {
            Length = data.Length;
            _data = data.Split('|');
            Id = ReadString();
        }

        public int ReadInt()
        {
            if (MoreToRead && int.TryParse(_data[_pointer++], out var result))
              return result;
            Log.Fatal("No more data to read");
            return 0;
        }
        public string ReadString()
        {
            if (MoreToRead) return _data[_pointer++];
            Log.Fatal("No more data to read");
            return "";
        }

        public double ReadDouble()
        {
            if (MoreToRead && double.TryParse(_data[_pointer++], out var result))
                return result;
            Log.Fatal("No more data to read");
            return 0;
        }

        public void Dispose()
        {
            _data = null;
            Id = null;
            _pointer = 0;
            Length = 0;
        }
    }
}
