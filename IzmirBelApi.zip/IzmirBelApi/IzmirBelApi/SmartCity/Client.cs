﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using IzmirBelApi.SmartCity.Commands;
using IzmirBelApi.SmartCity.Commands.Incoming;
using IzmirBelApi.SmartCity.Commands.Outgoing;
using log4net;

namespace IzmirBelApi.SmartCity
{
    internal class Client
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(Client));
        private const int BufferSizeMax = 4096;
        private readonly byte[] _buffer = new byte[BufferSizeMax];
        private Socket _socket;
        public bool SocketClosed { get; set; }
        public string Token { get; set; } = "";
        public bool Authenticated => Token != "";
        public DateTime LastPing { get; set; }
        public double Balance { get; set; } = 5;

        public Client(Socket socket)
        {
            _socket = socket;
            BeginReceive();
        }
        
        private void BeginReceive()
        {
            try
            {
                if (_socket == null || !_socket.Connected || SocketClosed)
                {
                    Disconnect();
                    return;
                }
                _socket?.BeginReceive(_buffer, 0, _buffer.Length, SocketFlags.None, OnReceiveData, null);
            }
            catch (Exception)
            {
                Disconnect();
            }
        }
        private void OnReceiveData(IAsyncResult result)
        {
            try
            {
                if (_socket == null || !_socket.Connected) return;

                var bytesRead = _socket?.EndReceive(result) ?? 0;
                if (bytesRead == 0)
                {
                    Disconnect();
                    return;
                }
                if (bytesRead >= BufferSizeMax) return;
                var b = new byte[bytesRead];
                Array.Copy(_buffer, b, bytesRead);
                var data = Encoding.UTF8.GetString(_buffer, 0, bytesRead).Replace("\n", "");
                using (var packet = new PacketParser(data))
                {
                    Log.Debug(packet.Id);
                    if (!CommandHandler.Handlers.TryGetValue(packet.Id, out var handler))
                    {
                        Log.Debug(
                            $"Handler not found for [{packet.Id}]");
                        return;
                    }
                    handler.Run(packet, this);

                }

                LastPing = DateTime.Now;
            }
            catch (Exception e)
            {
                Log.Error(e.Message);
            }
            finally
            {
                BeginReceive();
            }
        }
        public void Send(Command command)
        {
            try
            {
                if (_socket == null || !_socket.Connected) return;
                var byteData = Encoding.UTF8.GetBytes(command.Data + "\n");
                _socket.Send(byteData);
                
            }
            catch (SocketException e)
            {
                if (SocketClosed)
                {
                    if (e.NativeErrorCode.Equals(10035))
                    {
                    }
                    else
                    {
                        SocketClosed = true;
                        Disconnect();
                    }
                }
            }
        }
        public void Disconnect()
        {
            SocketClosed = true;
            try
            {
                _socket?.Shutdown(SocketShutdown.Both);
                _socket?.Close();
                _socket = null;
            }
            catch (Exception e)
            {
            }
            finally
            {
                SessionManager.RemoveSession(this);
            }
        }


    }
}
