﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace IzmirBelApi.SmartCity
{
    internal static class SessionManager
    {
        public static List<Client> Sessions { get; set; } = new List<Client>();
        public static int ConnectedUsers => Sessions.Count;
        public static void AddSession(Client client)
        {
            if (!Sessions.Contains(client))
                Sessions.Add(client);
        }
        public static void RemoveSession(Client client)
        {
            if (!Sessions.Contains(client)) return;
            Sessions.Remove(client);
        }

        public static void HandleIncomingConnection(Socket socket)
        {
            if (!socket.Connected) return;
            AddSession(new Client(socket));
        }

    }
}
