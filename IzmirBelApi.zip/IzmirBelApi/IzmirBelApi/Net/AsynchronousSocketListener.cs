﻿using System;
using System.Net;
using System.Net.Sockets;
using log4net;

namespace IzmirBelApi.Net
{
    /// <summary>
    /// callback to be invoked upon accepting A new connection.
    /// </summary>
    /// <param name="socket">Incoming socket connection</param>
    public delegate void OnNewConnectionCallback(Socket socket);

    /// <summary>
    /// simple asynchronous TCP listener.
    /// </summary>
    public class AsynchronousSocketListener : IDisposable
    {
        private Socket _socket;
        private readonly OnNewConnectionCallback _callback;
        private static readonly ILog Log = LogManager.GetLogger(typeof(AsynchronousSocketListener));

        public AsynchronousSocketListener(EndPoint localEndPoint, int backlog, OnNewConnectionCallback callback)
        {
            _callback = callback;
            _socket = new Socket(localEndPoint.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
            _socket.Bind(localEndPoint);
            _socket.Listen(backlog);
            _socket.Blocking = false;
            BeginAccept();
        }

        public void Dispose()
        {
            if (_socket == null) return;
            _socket.Dispose();
            _socket = null;
        }

        private void BeginAccept()
        {
            try
            {
                _socket.BeginAccept(OnAccept, null);
            }
            catch (Exception e)
            {
                Log.Error(e.Message);
            }
        }

        private void OnAccept(IAsyncResult result)
        {
            try
            {
                var resultSocket = _socket.EndAccept(result);
                _callback.Invoke(resultSocket);
            }
            catch (Exception e)
            {
                Log.Error(e.Message);
            }
            BeginAccept();
        }
    }
}
