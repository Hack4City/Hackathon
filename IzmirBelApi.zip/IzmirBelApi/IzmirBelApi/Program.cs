﻿using System;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Windows.Forms;
using IzmirBelApi.Hackathon;
using RestSharp;
using RestSharp.Authenticators;

namespace IzmirBelApi
{
    internal class Program
    {
        private static MainPanel _mainPanel;
        private static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //#if !DEBUG
                AppDomain.CurrentDomain.UnhandledException += UnhandledExceptionHandler;
            //#endif
            _mainPanel = new MainPanel();
            Application.Run(_mainPanel);
            //var hatlar = client.HatDuraklariniGetir(21, "UBSWS_HACKATHON", "re7Phy");
            //foreach (var arac in araclar.AracListe)
            //    Console.WriteLine($"{arac.AracTanimi} {arac.AracTipi}");
            //Console.WriteLine(araclar.AracListe.Count());
        }
        
        private static void UnhandledExceptionHandler(object sender, UnhandledExceptionEventArgs e)
        {
            var exception = e.ExceptionObject as Exception;
            const string filePath = "Crash Log.txt";
            using (var writer = new StreamWriter(filePath, true))
            {
                writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                writer.WriteLine("Exception :" + exception?.Message + "" + Environment.NewLine + "StackTrace :" + exception?.StackTrace);
                writer.WriteLine(DateTime.Now + Environment.NewLine);
            }
            Environment.Exit(-1);

        }

    }
}